from django.contrib import admin

# Register your models here.
from pvkadmin.models import home_banner, inquiry

admin.site.register(home_banner)
admin.site.register(inquiry)
