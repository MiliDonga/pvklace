from django.apps import AppConfig


class PvkadminConfig(AppConfig):
    name = 'pvkadmin'
