from django.db import models
import datetime
# Create your models here.

class product(models.Model):
    product_image = models.ImageField(upload_to='static/production/product')
    product_name = models.CharField(max_length=30)
    product_description = models.TextField()
    category = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=datetime.datetime.now())
    updated_at = models.DateTimeField(default=datetime.datetime.now())

class category(models.Model):
    category_image = models.ImageField(upload_to='static/production/category')
    category_name = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=datetime.datetime.now())
    updated_at = models.DateTimeField(default=datetime.datetime.now())

class team(models.Model):
    member_image = models.ImageField(upload_to='static/production/team')
    member_name = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=datetime.datetime.now())
    updated_at = models.DateTimeField(default=datetime.datetime.now())

class inquiry(models.Model):
    name = models.TextField()
    email = models.TextField()
    contact_no = models.BigIntegerField()
    item_name = models.IntegerField()
    created_at = models.DateTimeField(default=datetime.datetime.now())

class home_banner(models.Model):
    banner_image = models.ImageField(upload_to='static/production/home_banner')
    created_at = models.DateTimeField(default=datetime.datetime.now())
    updated_at = models.DateTimeField(default=datetime.datetime.now())

class about_us_banner(models.Model):
    about_us_banner = models.ImageField(upload_to='static/production/about_us_banner')
    created_at = models.DateTimeField(default=datetime.datetime.now())
    updated_at = models.DateTimeField(default=datetime.datetime.now())
