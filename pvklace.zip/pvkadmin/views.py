import datetime
import os

from django.http.response import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from pvkadmin.models import category, product, home_banner, team, inquiry


# Create your views here.
def admin_login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        if username != "" and password != "":
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request,user)
                return redirect("dashboard/")
            else:
                return render(request, "admin_login.html", {"error": "Username or password is incorrect."})
        else:
            return render(request, "admin_login.html",{"error":"Please fill all the field."})
    return render(request,"admin_login.html")

@login_required(login_url="/admin-side/")
def admin_index(request):
    inq = inquiry.objects.all().order_by('created_at').values()
    for item in inq:
        print(item)
        pro = product.objects.get(id=item['item_name'])
        cat = category.objects.get(id=pro.category)
        item['item_name']=pro.product_name
        item['category']=cat.category_name
    return render(request,"admin_index.html",{"inquiry": inq})

@login_required(login_url="/admin-side/")
def admin_category(request):
    cat = category.objects.all().values()
    return render(request,"admin_category.html",{'category':cat})

@login_required(login_url="/admin-side/")
def admin_home_banner(request):
    home = home_banner.objects.all().values()
    data = {
        'banner_1': home[0]['banner_image'],
        'banner_2': home[1]['banner_image'],
        'banner_3': home[2]['banner_image'],
    }
    return render(request,"admin_home-banner-images.html",data)

@login_required(login_url="/admin-side/")
def admin_product(request):
    pro = product.objects.all().values()
    cat = category.objects.all().filter(is_active=True).values()
    categories = {}
    for item in pro:
        id = item['category']
        item['category']=category.objects.get(id=id).category_name
    for item in cat:
        categories[item['id']] = item['category_name']
    data = {
        'category': categories,
        'product': pro
    }
    return render(request,"admin_products.html",data)

@login_required(login_url="/admin-side/")
def admin_team(request):
    tea = team.objects.all().values()
    return render(request,"admin_team.html",{'team':tea})

@login_required(login_url="/admin-side/")
def admin_about_banner(request):
    return render(request,"admin_about-us-banner-images.html")

@login_required(login_url="/admin-side/")
def admin_logout(request):
    logout(request)
    return redirect("/admin-side/")

@login_required(login_url="/admin-side/")
def add_category(request):
    if request.method == "POST" and request.FILES['image']:
        cat = category(category_image=request.FILES['image'],category_name=request.POST['name'])
        cat.save()
        request.session['add'] = 1
        return redirect("/admin-side/category/")

@login_required(login_url="/admin-side/")
def update_session(request):
    request.session['update'] = 0
    return HttpResponse('ok')

@login_required(login_url="/admin-side/")
def add_session(request):
    request.session['add'] = 0
    return HttpResponse('ok')

@login_required(login_url="/admin-side/")
def get_category_data(request):
    cat = category.objects.get(id=request.GET.get('id'))
    data = {
        'id': cat.id,
        'name': cat.category_name,
    }
    return JsonResponse({"data": data})

@login_required(login_url="/admin-side/")
def update_category(request):
    if request.method == "POST":
        if 'image' in request.FILES:
            cat = category.objects.get(id=request.POST['id'])
            os.remove(str(cat.category_image))
            cat.category_image = request.FILES['image']
            cat.category_name=request.POST['name']
            cat.updated_at=datetime.datetime.now()
            cat.save()
        else:
            category.objects.filter(id=request.POST['id']).update(category_name=request.POST['name'],
                                                                  updated_at=datetime.datetime.now())

        request.session['update'] = 1
        return redirect("/admin-side/category/")

@login_required(login_url="/admin-side/")
def category_status(request):
    cat = category.objects.get(id=request.GET['id'])
    if cat.is_active:
        cat.is_active = False
        product.objects.all().filter(category=cat.id).update(is_active=False)
    else:
        cat.is_active = True
        product.objects.all().filter(category=cat.id).update(is_active=True)
    cat.updated_at = datetime.datetime.now()
    cat.save()
    request.session['update'] = 1
    return HttpResponse("OK")

@login_required(login_url="/admin-side/")
def get_product_data(request):
    pro = product.objects.get(id=request.GET.get('id'))
    data = {
        'id': pro.id,
        'name': pro.product_name,
        'description': pro.product_description,
        'category': pro.category,
    }
    return JsonResponse({"data": data})

@login_required(login_url="/admin-side/")
def add_product(request):
    if request.method == "POST" and request.FILES['product_image']:
        pro = product(product_image=request.FILES['product_image'],product_name=request.POST['name'],product_description=request.POST['product_description'],category=request.POST['category'])
        pro.save()
        request.session['add'] = 1
        return redirect("/admin-side/product/")

@login_required(login_url="/admin-side/")
def product_status(request):
    pro = product.objects.get(id=request.GET['id'])
    if pro.is_active:
        pro.is_active = False
    else:
        pro.is_active = True
    pro.updated_at = datetime.datetime.now()
    pro.save()
    request.session['update'] = 1
    return HttpResponse("OK")

@login_required(login_url="/admin-side/")
def update_product(request):

    if request.method == "POST":
        if 'image' in request.FILES:
            pro = product.objects.get(id=request.POST.get('id'))
            os.remove(str(pro.product_image))
            pro.product_image = request.FILES['image']
            pro.product_name=request.POST['name']
            pro.product_description=request.POST['product_description']
            pro.category=request.POST['category']
            pro.updated_at=datetime.datetime.now()
            pro.save()
        else:
            product.objects.filter(id=request.POST['id']).update(product_name=request.POST['name'],product_description=request.POST['product_description'],category=request.POST['category'],
                                                                  updated_at=datetime.datetime.now())

        request.session['update'] = 1
        return redirect("/admin-side/product/")

@login_required(login_url="/admin-side/")
def update_home(request):
    if request.method == "POST" and request.FILES['image']:
        home = home_banner.objects.get(id=request.POST.get('id'))
        os.remove(str(home.banner_image))
        print(request.FILES['image'])
        home.banner_image = request.FILES['image']
        home.save()
        request.session['update'] = 1
        return redirect("/admin-side/home_banner/")

@login_required(login_url="/admin-side/")
def add_team(request):
    if request.method == "POST" and request.FILES['image']:
        tea = team(member_image=request.FILES['image'],member_name=request.POST['name'])
        tea.save()
        request.session['add'] = 1
        return redirect("/admin-side/team/")

@login_required(login_url="/admin-side/")
def team_status(request):
    tea = team.objects.get(id=request.GET['id'])
    if tea.is_active:
        tea.is_active = False
    else:
        tea.is_active = True
    tea.updated_at = datetime.datetime.now()
    tea.save()
    request.session['update'] = 1
    return HttpResponse("OK")

@login_required(login_url="/admin-side/")
def update_team(request):

    if request.method == "POST":
        if 'image' in request.FILES:
            tea = team.objects.get(id=request.POST.get('id'))
            os.remove(str(tea.member_image))
            tea.member_image = request.FILES['image']
            tea.member_name=request.POST['name']
            tea.updated_at=datetime.datetime.now()
            tea.save()
        else:
            team.objects.filter(id=request.POST['id']).update(member_name=request.POST['name'],
                                                                  updated_at=datetime.datetime.now())

        request.session['update'] = 1
        return redirect("/admin-side/team/")

@login_required(login_url="/admin-side/")
def get_team_data(request):
    tea = team.objects.get(id=request.GET.get('id'))
    data = {
        'id': tea.id,
        'name': tea.member_name,
    }
    return JsonResponse({"data": data})