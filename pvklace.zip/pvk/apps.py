from django.apps import AppConfig


class PvkConfig(AppConfig):
    name = 'pvk'
