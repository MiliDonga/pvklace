from django.urls import path
from django.views.generic import TemplateView

from pvk import views

urlpatterns = [
    path('', views.index, name="index"),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('artwork/', views.artwork, name='artwork'),
    path('add_inquiry/', views.add_inquiry, name='add_inquiry'),
    path('add_session/', views.add_session, name='add_session'),
]