from django.http.response import HttpResponse
from django.shortcuts import render, redirect

# Create your views here.
from pvkadmin.models import category, home_banner, team, product, inquiry


def index(request):
    cat = category.objects.all().filter(is_active=True).values()
    home = home_banner.objects.all().values()
    data = {
        'category': cat,
        'banner': home,
    }
    return render(request,"index.html",data)

def about(request):
    tea = team.objects.all().filter(is_active=True).values()
    data = {
        'team': tea,
    }
    return render(request,"about.html",data)

def contact(request):
    return render(request,"contact.html")

def artwork(request):
    cat = category.objects.all().filter(is_active=True).values()
    pro = product.objects.all().values()
    for item in pro:
        id = item['category']
        item['category'] = category.objects.get(id=id).category_name
    data = {
        'category': cat,
        'product': pro,
    }
    return render(request,"artwork.html",data)

def add_inquiry(request):
    if request.method == 'POST':
        inq = inquiry(name=request.POST['name'],email=request.POST['email'],contact_no=request.POST['contact'],item_name=request.POST['item_name'])
        inq.save()
        request.session['add'] = 1
        return redirect("/artwork/")

def add_session(request):
    request.session['add'] = 0
    return HttpResponse('ok')